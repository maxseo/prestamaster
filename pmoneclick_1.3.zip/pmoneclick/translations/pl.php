<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pmoneclick}prestashop>pmoneclick_674be76166ddaff853b0aa2eb2806378'] = 'Kup jednym kliknięciem';
$_MODULE['<{pmoneclick}prestashop>pmoneclick_4d604680408d36bdcfecc3847502490b'] = 'Pozwól złożyć szybkie zamówienie';
$_MODULE['<{pmoneclick}prestashop>pmoneclick_208f156d4a803025c284bb595a7576b4'] = 'włączyć';
$_MODULE['<{pmoneclick}prestashop>pmoneclick_0aaa87422396fdd678498793b6d5250e'] = 'wyłączyć';
$_MODULE['<{pmoneclick}prestashop>front_1029f27c72a584d2fe7a494a6597ba7d'] = 'Zamówienie jednym kliknięciem:';
$_MODULE['<{pmoneclick}prestashop>front_d6d513871a3903be249dbc3bb8a17e7c'] = 'Twoje zamówienie zostało przyjęte! Numer zamówienia:';
$_MODULE['<{pmoneclick}prestashop>front_825791e37d785492fa3fc5ec571aa17e'] = 'Alias adresu za jednym kliknięciem';
$_MODULE['<{pmoneclick}prestashop>front_41d685aa3886270ce96827866455a25f'] = 'Adres jednym kliknięciem';
$_MODULE['<{pmoneclick}prestashop>front_17bd8f74b95a87e8ee84f59f3126b134'] = 'Miasto jednym kliknięciem';
$_MODULE['<{pmoneclick}prestashop>confirm_popup_864745c67f00fce2c20fa8ff3f9df2e4'] = 'Twoje zamówienie zostało przyjęte!';
$_MODULE['<{pmoneclick}prestashop>confirm_popup_7bc9924cbe45f163d7dda2198909d937'] = 'Numer zamówienia: %s!';
$_MODULE['<{pmoneclick}prestashop>popup_1e884e3078d9978e216a027ecd57fb34'] = 'E-mail';
$_MODULE['<{pmoneclick}prestashop>popup_49ee3087348e8d44e1feda1917443987'] = 'Nazwa';
$_MODULE['<{pmoneclick}prestashop>popup_bcc254b55c4a1babdf1dcb82c207506b'] = 'Telefon';
$_MODULE['<{pmoneclick}prestashop>popup_0ab608f7e0d1501be457f7646c1e57c0'] = 'Kod promocyjny';
$_MODULE['<{pmoneclick}prestashop>popup_70d9be9b139893aa6c69b5e77e614311'] = 'Potwierdzać';
$_MODULE['<{pmoneclick}prestashop>oneclick_button_eeceac1af4e7620894d6d2083921bb73'] = 'Kup Teraz';
